﻿namespace ChanSort.Api
{
  public class NetworkInfo
  {
    public int OriginalNetworkId { get; set; }
    public string Name { get; set; }
    public string Operator { get; set; }
  }
}
